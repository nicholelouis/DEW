let img = document.getElementById('img');
let posicionX = 0;

img.onclick= function(){
    posicionX += 20;
    img.style.left = posicionX + 'px';
}






