function mostrarAlerta(reino) {
    alert("Has hecho clic en: " + reino);
}