document.getElementById('o').addEventListener('click', function(){
    document.body.style.background="black";
});

document.getElementById('l').addEventListener('click', function(){
    document.body.style.background="yellow";
});