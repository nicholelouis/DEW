let anillo = document.getElementById("anillo");

anillo.addEventListener('click', function(){
    document.body.innerHTML = "<h1 style=text-align:center;>Has Elegido Correctamente</h1>"
})