document.getElementById('btn').addEventListener('click', function(){
    document.body.style.backgroundImage = "url('./bat.jpg')";
})