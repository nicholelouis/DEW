const g = document.getElementById('groot');

g.addEventListener('click', function(){
    alert('¡¡¡YO SOY GROOT!!!');
})